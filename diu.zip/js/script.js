document.addEventListener('DOMContentLoaded', function() {
    // Set current year in the footer
    document.getElementById('currentYear').textContent = new Date().getFullYear();
    
    // Get form elements
    const resultForm = document.getElementById('resultForm');
    const studentIdInput = document.getElementById('studentId');
    const semesterIdInput = document.getElementById('semesterId');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const resultContainer = document.getElementById('resultContainer');
    const errorContainer = document.getElementById('errorContainer');
    const errorMessage = document.getElementById('errorMessage');
    const printResultBtn = document.getElementById('printResult');
    const downloadPdfBtn = document.getElementById('downloadPdf');
    const newSearchBtn = document.getElementById('newSearch');
    const semesterBadge = document.getElementById('semesterBadge');
    
    // Handle form submission
    resultForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get input values
        const studentId = studentIdInput.value.trim();
        const semesterId = semesterIdInput.value.trim();
        
        // Validate inputs
        if (!studentId || !semesterId) {
            showError('Please enter both Student ID and Semester ID.');
            return;
        }
        
        // Validate student ID format (XXX-XX-XXX)
        const studentIdPattern = /^\d{3}-\d{2}-\d{3}$/;
        if (!studentIdPattern.test(studentId)) {
            showError('Please enter a valid Student ID format (e.g., 251-27-014).');
            return;
        }
        
        // Validate semester ID
        if (!/^\d+$/.test(semesterId)) {
            showError('Please enter a valid Semester ID (numeric only).');
            return;
        }
        
        // Hide any previous error
        hideError();
        
        // Show loading indicator
        showLoading();
        
        // Hide result container if it was previously shown
        resultContainer.classList.add('d-none');
        
        // Fetch result from the API
        fetchResult(studentId, semesterId);
    });
    
    // Handle print button click
    printResultBtn.addEventListener('click', function() {
        window.print();
    });
    
    // Handle download PDF button click
    downloadPdfBtn.addEventListener('click', function() {
        generatePDF();
    });
    
    // Handle new search button click
    newSearchBtn.addEventListener('click', function() {
        // Hide result container
        resultContainer.classList.add('d-none');
        
        // Show form
        resultForm.reset();
        hideLoading();
        hideError();
        
        // Scroll to top
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
    
    /**
     * Function to fetch student result from the API
     */
    function fetchResult(studentId, semesterId) {
        // API URL
        const apiUrl = `https://diurecords.vercel.app/api/result?grecaptcha=&semesterId=${semesterId}&studentId=${studentId}`;
        
        fetch(apiUrl)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Server responded with status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                // Hide loading indicator
                hideLoading();
                
                // Process and display the result
                processAndDisplayResult(data);
            })
            .catch(error => {
                // Hide loading indicator
                hideLoading();
                
                // Show error message
                showError('Failed to fetch result. Please check your Student ID and Semester ID and try again. ' + error.message);
                console.error('Error fetching result:', error);
            });
    }
    
    /**
     * Function to process and display the result
     */
    function processAndDisplayResult(data) {
        // Check if data is valid
        if (!data || !Array.isArray(data) || data.length === 0) {
            showError('No results found. Please check your Student ID and Semester ID.');
            return;
        }
        
        try {
            // Get first item to extract student info
            const firstItem = data[0];
            
            // Extract student and semester info from the first result
            const studentId = firstItem.studentId || 'N/A';
            const semesterName = firstItem.semesterName || 'N/A';
            const semesterYear = firstItem.semesterYear || 'N/A';
            const cgpa = firstItem.cgpa || 'N/A';
            
            // Update the semester badge
            semesterBadge.textContent = `${semesterName} ${semesterYear}`;
            
            // Fill student information
            document.getElementById('studentName').textContent = 'Student'; // API doesn't provide name
            document.getElementById('studentIdDisplay').textContent = studentId;
            document.getElementById('program').textContent = 'Program'; // API doesn't provide program
            document.getElementById('cgpa').textContent = cgpa;
            
            // Add CGPA color based on value
            const cgpaElement = document.getElementById('cgpa');
            if (cgpa >= 3.5) {
                cgpaElement.classList.add('text-success');
            } else if (cgpa >= 3.0) {
                cgpaElement.classList.add('text-primary');
            } else if (cgpa < 2.5) {
                cgpaElement.classList.add('text-danger');
            }
            
            // Fill result table
            const resultTableBody = document.getElementById('resultTableBody');
            resultTableBody.innerHTML = ''; // Clear previous results
            
            // Process each course in the result
            data.forEach(course => {
                const row = document.createElement('tr');
                
                // Add CSS class based on grade
                if (course.gradeLetter === 'F') {
                    row.classList.add('table-danger');
                } else if (course.gradeLetter === 'A' || course.gradeLetter === 'A+') {
                    row.classList.add('table-success');
                } else if (course.gradeLetter === 'B+' || course.gradeLetter === 'B') {
                    row.classList.add('table-info');
                }
                
                // Get motivational message based on grade
                const motivationalMessage = getMotivationalMessage(course.gradeLetter, course.pointEquivalent);
                
                row.innerHTML = `
                    <td><strong>${course.customCourseId || 'N/A'}</strong></td>
                    <td>
                        ${course.courseTitle || 'N/A'}
                        <div class="motivational-message">${motivationalMessage}</div>
                    </td>
                    <td class="text-center">${course.totalCredit || 'N/A'}</td>
                    <td class="text-center"><span class="badge ${getBadgeClass(course.gradeLetter)}">${course.gradeLetter || 'N/A'}</span></td>
                    <td class="text-center">${course.pointEquivalent || 'N/A'}</td>
                `;
                
                resultTableBody.appendChild(row);
            });
            
            // Add overall motivational message based on CGPA
            addOverallMotivationalMessage(cgpa);
            
            // Show result container
            resultContainer.classList.remove('d-none');
            
            // Scroll to result section
            setTimeout(() => {
                resultContainer.scrollIntoView({
                    behavior: 'smooth'
                });
            }, 300);
        } catch (error) {
            showError('Error processing result data. ' + error.message);
            console.error('Error processing result:', error);
        }
    }
    
    /**
     * Function to add an overall motivational message based on CGPA
     */
    function addOverallMotivationalMessage(cgpa) {
        let message = '';
        let messageClass = '';
        
        if (cgpa >= 3.8) {
            message = "Outstanding achievement! Your hard work has truly paid off. Keep up this excellence!";
            messageClass = "text-success";
        } else if (cgpa >= 3.5) {
            message = "Excellent work! You're performing at a high level. Continue pushing your boundaries!";
            messageClass = "text-success";
        } else if (cgpa >= 3.0) {
            message = "Great job! Your dedication is showing in your results. Keep building on this solid foundation!";
            messageClass = "text-primary";
        } else if (cgpa >= 2.5) {
            message = "Good progress! With continued focus, you can achieve even greater academic success!";
            messageClass = "text-info";
        } else if (cgpa >= 2.0) {
            message = "You're on the right track! A bit more effort in challenging areas could boost your results.";
            messageClass = "text-warning";
        } else {
            message = "This is an opportunity for growth. Don't give up! Reach out for support and keep pushing forward.";
            messageClass = "text-danger";
        }
        
        // Check if motivational container already exists, if not create it
        let motivationalContainer = document.querySelector('.motivational-container');
        if (!motivationalContainer) {
            motivationalContainer = document.createElement('div');
            motivationalContainer.className = 'motivational-container card mt-4';
            
            const cardBody = document.createElement('div');
            cardBody.className = 'card-body text-center';
            
            const heading = document.createElement('h4');
            heading.className = 'mb-3';
            heading.innerHTML = '<i class="fas fa-quote-left me-2"></i>Words of Encouragement<i class="fas fa-quote-right ms-2"></i>';
            
            const messageElement = document.createElement('p');
            messageElement.className = `motivational-message-overall ${messageClass}`;
            messageElement.textContent = message;
            
            cardBody.appendChild(heading);
            cardBody.appendChild(messageElement);
            motivationalContainer.appendChild(cardBody);
            
            // Insert before the action buttons
            const actionsContainer = document.querySelector('.result-actions');
            resultContainer.insertBefore(motivationalContainer, actionsContainer);
        } else {
            // Update existing message
            const messageElement = motivationalContainer.querySelector('.motivational-message-overall');
            messageElement.textContent = message;
            messageElement.className = `motivational-message-overall ${messageClass}`;
        }
    }
    
    /**
     * Function to get motivational message based on grade letter and points
     */
    function getMotivationalMessage(gradeLetter, points) {
        // No motivational message for null or undefined grades
        if (!gradeLetter) return '';
        
        switch(gradeLetter) {
            case 'A+':
                return "<span class='text-success'><i class='fas fa-star'></i> Perfect! Outstanding mastery of this subject.</span>";
            case 'A':
                return "<span class='text-success'><i class='fas fa-medal'></i> Excellent! Your hard work clearly shows.</span>";
            case 'A-':
                return "<span class='text-success'><i class='fas fa-thumbs-up'></i> Great work! You've demonstrated strong knowledge.</span>";
            case 'B+':
                return "<span class='text-primary'><i class='fas fa-arrow-trend-up'></i> Very good performance! Keep building on this.</span>";
            case 'B':
                return "<span class='text-primary'><i class='fas fa-check-circle'></i> Good job! You've shown solid understanding.</span>";
            case 'B-':
                return "<span class='text-info'><i class='fas fa-lightbulb'></i> Decent work - with a bit more effort, you can achieve even more!</span>";
            case 'C+':
                return "<span class='text-info'><i class='fas fa-arrow-up'></i> You're heading in the right direction. Keep improving!</span>";
            case 'C':
                return "<span class='text-warning'><i class='fas fa-book'></i> You've grasped the basics. Focus on deeper understanding.</span>";
            case 'D':
                return "<span class='text-warning'><i class='fas fa-exclamation-circle'></i> You passed, but consider strengthening this area.</span>";
            case 'F':
                return "<span class='text-danger'><i class='fas fa-hand-holding-heart'></i> This is an opportunity to learn and grow. Don't give up!</span>";
            default:
                return "";
        }
    }
    
    /**
     * Function to get badge class based on grade letter
     */
    function getBadgeClass(gradeLetter) {
        switch(gradeLetter) {
            case 'A+':
            case 'A':
                return 'bg-success';
            case 'A-':
            case 'B+':
                return 'bg-primary';
            case 'B':
            case 'B-':
                return 'bg-info';
            case 'C+':
            case 'C':
                return 'bg-warning';
            case 'D':
                return 'bg-warning text-dark';
            case 'F':
                return 'bg-danger';
            default:
                return 'bg-secondary';
        }
    }
    
    /**
     * Function to generate PDF from result
     */
    function generatePDF() {
        // Show loading message
        showError("Generating PDF, please wait...");
        
        // Create a fresh container for PDF content
        const pdfContent = document.createElement('div');
        pdfContent.className = 'pdf-content';
        pdfContent.style.padding = '15px';
        pdfContent.style.fontFamily = 'Arial, sans-serif';
        
        // Add DIU header
        const header = document.createElement('div');
        header.style.textAlign = 'center';
        header.style.marginBottom = '20px';
        header.innerHTML = `
            <div style="margin-bottom: 10px;">
                <img src="https://daffodilvarsity.edu.bd/template/images/diulogo.png" alt="DIU Logo" style="height: 70px;">
            </div>
            <h2 style="color: #006A4E; margin: 5px 0;">Daffodil International University</h2>
            <p style="font-size: 16px; margin: 5px 0;">Academic Result</p>
            <p style="font-size: 14px; margin: 5px 0; color: #666;">${document.getElementById('semesterBadge').textContent}</p>
        `;
        pdfContent.appendChild(header);
        
        // Student Information
        const studentInfo = document.createElement('div');
        studentInfo.style.marginBottom = '20px';
        studentInfo.style.border = '1px solid #ddd';
        studentInfo.style.borderRadius = '5px';
        studentInfo.style.padding = '10px';
        
        const studentId = document.getElementById('studentIdDisplay').textContent;
        const studentName = document.getElementById('studentName').textContent;
        const program = document.getElementById('program').textContent;
        const cgpa = document.getElementById('cgpa').textContent;
        
        studentInfo.innerHTML = `
            <h3 style="color: #006A4E; margin-top: 0; border-bottom: 1px solid #eee; padding-bottom: 8px;">Student Information</h3>
            <table style="width: 100%;">
                <tr>
                    <td style="width: 25%; padding: 8px;"><strong>Student ID:</strong></td>
                    <td style="width: 25%; padding: 8px;">${studentId}</td>
                    <td style="width: 25%; padding: 8px;"><strong>Name:</strong></td>
                    <td style="width: 25%; padding: 8px;">${studentName}</td>
                </tr>
                <tr>
                    <td style="padding: 8px;"><strong>Program:</strong></td>
                    <td style="padding: 8px;">${program}</td>
                    <td style="padding: 8px;"><strong>CGPA:</strong></td>
                    <td style="padding: 8px; font-weight: bold; color: #006A4E;">${cgpa}</td>
                </tr>
            </table>
        `;
        
        pdfContent.appendChild(studentInfo);
        
        // Course Results
        const courseInfo = document.createElement('div');
        courseInfo.style.marginBottom = '20px';
        
        // Get course data
        const resultRows = document.querySelectorAll('#resultTableBody tr');
        
        courseInfo.innerHTML = `
            <h3 style="color: #006A4E; margin-top: 0;">Course Results</h3>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                <thead>
                    <tr style="background-color: #006A4E; color: white;">
                        <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">Course Code</th>
                        <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">Course Title</th>
                        <th style="padding: 10px; text-align: center; border: 1px solid #ddd;">Credit</th>
                        <th style="padding: 10px; text-align: center; border: 1px solid #ddd;">Grade</th>
                        <th style="padding: 10px; text-align: center; border: 1px solid #ddd;">Points</th>
                    </tr>
                </thead>
                <tbody>
                    ${Array.from(resultRows).map(row => {
                        const cells = row.querySelectorAll('td');
                        const courseCode = cells[0].innerText;
                        const courseTitle = cells[1].innerText.split('\n')[0]; // Get only the title, not the motivational message
                        const credit = cells[2].innerText;
                        const grade = cells[3].innerText;
                        const points = cells[4].innerText;
                        
                        // Set row background based on grade
                        let rowStyle = '';
                        if (grade === 'A+' || grade === 'A') {
                            rowStyle = 'background-color: #d4edda;';
                        } else if (grade === 'B+' || grade === 'B') {
                            rowStyle = 'background-color: #d1ecf1;';
                        } else if (grade === 'F') {
                            rowStyle = 'background-color: #f8d7da;';
                        }
                        
                        return `
                            <tr style="${rowStyle}">
                                <td style="padding: 8px; border: 1px solid #ddd;"><strong>${courseCode}</strong></td>
                                <td style="padding: 8px; border: 1px solid #ddd;">${courseTitle}</td>
                                <td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${credit}</td>
                                <td style="padding: 8px; border: 1px solid #ddd; text-align: center; font-weight: bold;">${grade}</td>
                                <td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${points}</td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;
        
        pdfContent.appendChild(courseInfo);
        
        // Add motivational message
        const motivationalElement = document.querySelector('.motivational-message-overall');
        if (motivationalElement) {
            const motivationalMsg = document.createElement('div');
            motivationalMsg.style.textAlign = 'center';
            motivationalMsg.style.padding = '15px';
            motivationalMsg.style.backgroundColor = '#f8f9fa';
            motivationalMsg.style.borderRadius = '5px';
            motivationalMsg.style.marginBottom = '20px';
            
            motivationalMsg.innerHTML = `
                <h4 style="margin-top: 0; color: #006A4E;">Words of Encouragement</h4>
                <p style="font-size: 16px; font-style: italic;">"${motivationalElement.textContent}"</p>
            `;
            
            pdfContent.appendChild(motivationalMsg);
        }
        
        // Footer
        const footer = document.createElement('div');
        footer.style.borderTop = '1px solid #ddd';
        footer.style.paddingTop = '10px';
        footer.style.marginTop = '20px';
        footer.style.fontSize = '12px';
        footer.style.color = '#666';
        footer.style.textAlign = 'center';
        footer.innerHTML = `
            <p>Generated on ${new Date().toLocaleDateString()} | Daffodil International University</p>
            <p>This is an unofficial result document.</p>
        `;
        
        pdfContent.appendChild(footer);
        
        // Temporarily add to document for PDF generation
        pdfContent.style.position = 'absolute';
        pdfContent.style.left = '-9999px';
        document.body.appendChild(pdfContent);
        
        // PDF options
        const options = {
            margin: 10,
            filename: `DIU_Result_${studentId}.pdf`,
            image: { type: 'jpeg', quality: 1 },
            html2canvas: { scale: 2, useCORS: true },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
        };
        
        // Generate PDF after a brief timeout to ensure complete rendering
        setTimeout(() => {
            // Use html2pdf with the explicit static HTML content
            html2pdf()
                .from(pdfContent)
                .set(options)
                .save()
                .then(() => {
                    // Clean up - remove temp element
                    document.body.removeChild(pdfContent);
                    hideError();
                })
                .catch(error => {
                    console.error('PDF generation error:', error);
                    showError('Failed to generate PDF. Please try again.');
                    document.body.removeChild(pdfContent);
                });
        }, 100);
    }
    
    /**
     * Function to show loading indicator
     */
    function showLoading() {
        loadingIndicator.classList.remove('d-none');
    }
    
    /**
     * Function to hide loading indicator
     */
    function hideLoading() {
        loadingIndicator.classList.add('d-none');
    }
    
    /**
     * Function to show error message
     */
    function showError(message) {
        errorMessage.textContent = message;
        errorContainer.classList.remove('d-none');
        
        // Scroll to error message
        errorContainer.scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });
    }
    
    /**
     * Function to hide error message
     */
    function hideError() {
        errorContainer.classList.add('d-none');
    }
});